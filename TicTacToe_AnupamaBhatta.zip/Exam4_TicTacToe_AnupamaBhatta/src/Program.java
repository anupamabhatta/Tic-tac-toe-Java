
/** Name: Anupama Bhatta
 *  Date: 05/06/2019
 *  Description: Develop Tic-Tac-Toe game that uses Algorithm Engine Library.
 */

public class Program {
    public static void main(String[] args) 
    {
        UI_Enter form = new UI_Enter();
        form.setVisible(true);       
//        (new UI_Game(5, "Anupama", true, 3)).setVisible(true);
    } 
}
